module.exports = {
    Super: 'Super',
    General: 'General'
}